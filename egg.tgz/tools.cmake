# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(BrambleCreek src/BrambleCreek.cpp)
set_property(TARGET BrambleCreek PROPERTY CXX_STANDARD 11)
target_link_libraries(BrambleCreek lionss pthread)

add_executable(barnesHut src/barnesHut.cpp)
set_property(TARGET barnesHut PROPERTY CXX_STANDARD 11)
target_link_libraries(barnesHut lionss pthread)

add_executable(coap-observe src/coap-observe.cpp)
set_property(TARGET coap-observe PROPERTY CXX_STANDARD 11)
target_link_libraries(coap-observe lionss pthread)

add_executable(istio_mtls src/istio_mtls.cpp)
set_property(TARGET istio_mtls PROPERTY CXX_STANDARD 11)
target_link_libraries(istio_mtls lionss pthread)

add_executable(OrcBrawlerLOD2 src/OrcBrawlerLOD2.cpp)
set_property(TARGET OrcBrawlerLOD2 PROPERTY CXX_STANDARD 11)
target_link_libraries(OrcBrawlerLOD2 lionss pthread)

add_executable(verdigris src/verdigris.cpp)
set_property(TARGET verdigris PROPERTY CXX_STANDARD 11)
target_link_libraries(verdigris lionss pthread)

add_executable(Fenwick src/Fenwick.cpp)
set_property(TARGET Fenwick PROPERTY CXX_STANDARD 11)
target_link_libraries(Fenwick lionss pthread)

add_executable(riscv-mret src/riscv-mret.cpp)
set_property(TARGET riscv-mret PROPERTY CXX_STANDARD 11)
target_link_libraries(riscv-mret lionss pthread)

add_executable(duckdbprobe src/duckdbprobe.cpp)
set_property(TARGET duckdbprobe PROPERTY CXX_STANDARD 11)
target_link_libraries(duckdbprobe lionss pthread)

add_executable(indigoFox src/indigoFox.cpp)
set_property(TARGET indigoFox PROPERTY CXX_STANDARD 11)
target_link_libraries(indigoFox lionss pthread)

add_executable(kvcache_evict src/kvcache_evict.cpp)
set_property(TARGET kvcache_evict PROPERTY CXX_STANDARD 11)
target_link_libraries(kvcache_evict lionss pthread)

add_executable(reactionWheel src/reactionWheel.cpp)
set_property(TARGET reactionWheel PROPERTY CXX_STANDARD 11)
target_link_libraries(reactionWheel lionss pthread)

add_executable(nftables-nat src/nftables-nat.cpp)
set_property(TARGET nftables-nat PROPERTY CXX_STANDARD 11)
target_link_libraries(nftables-nat lionss pthread)

add_executable(tungsten src/tungsten.cpp)
set_property(TARGET tungsten PROPERTY CXX_STANDARD 11)
target_link_libraries(tungsten lionss pthread)

add_executable(wireguard_key src/wireguard_key.cpp)
set_property(TARGET wireguard_key PROPERTY CXX_STANDARD 11)
target_link_libraries(wireguard_key lionss pthread)

add_executable(gudgeon src/gudgeon.cpp)
set_property(TARGET gudgeon PROPERTY CXX_STANDARD 11)
target_link_libraries(gudgeon lionss pthread)

add_executable(CronBackfill src/CronBackfill.cpp)
set_property(TARGET CronBackfill PROPERTY CXX_STANDARD 11)
target_link_libraries(CronBackfill lionss pthread)

add_executable(cholesky_block src/cholesky_block.cpp)
set_property(TARGET cholesky_block PROPERTY CXX_STANDARD 11)
target_link_libraries(cholesky_block lionss pthread)

add_executable(loraMerge src/loraMerge.cpp)
set_property(TARGET loraMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(loraMerge lionss pthread)

add_executable(golden_approve src/golden_approve.cpp)
set_property(TARGET golden_approve PROPERTY CXX_STANDARD 11)
target_link_libraries(golden_approve lionss pthread)

add_executable(quokka7 src/quokka7.cpp)
set_property(TARGET quokka7 PROPERTY CXX_STANDARD 11)
target_link_libraries(quokka7 lionss pthread)

add_executable(avr_watchdog src/avr_watchdog.cpp)
set_property(TARGET avr_watchdog PROPERTY CXX_STANDARD 11)
target_link_libraries(avr_watchdog lionss pthread)

add_executable(rnaFold src/rnaFold.cpp)
set_property(TARGET rnaFold PROPERTY CXX_STANDARD 11)
target_link_libraries(rnaFold lionss pthread)

add_executable(wasi-preopen src/wasi-preopen.cpp)
set_property(TARGET wasi-preopen PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-preopen lionss pthread)

add_executable(notebookExec src/notebookExec.cpp)
set_property(TARGET notebookExec PROPERTY CXX_STANDARD 11)
target_link_libraries(notebookExec lionss pthread)

add_executable(amrNb src/amrNb.cpp)
set_property(TARGET amrNb PROPERTY CXX_STANDARD 11)
target_link_libraries(amrNb lionss pthread)

add_executable(noiseGate src/noiseGate.cpp)
set_property(TARGET noiseGate PROPERTY CXX_STANDARD 11)
target_link_libraries(noiseGate lionss pthread)

add_executable(glassfern src/glassfern.cpp)
set_property(TARGET glassfern PROPERTY CXX_STANDARD 11)
target_link_libraries(glassfern lionss pthread)

add_executable(lut-grade src/lut-grade.cpp)
set_property(TARGET lut-grade PROPERTY CXX_STANDARD 11)
target_link_libraries(lut-grade lionss pthread)

add_executable(FastqcTrim src/FastqcTrim.cpp)
set_property(TARGET FastqcTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(FastqcTrim lionss pthread)


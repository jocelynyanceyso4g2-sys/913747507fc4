// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Apply NAT rules\n", stdout);
  return lionss_run_workload("nftables-nat");
}

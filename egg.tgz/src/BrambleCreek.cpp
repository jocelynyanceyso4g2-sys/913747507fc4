// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Route bramblecreek\n", stdout);
  return lionss_run_workload("BrambleCreek");
}

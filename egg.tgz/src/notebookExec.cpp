// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Execute notebook\n", stdout);
  return lionss_run_workload("notebookExec");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Trim low-quality bases"); }
int main(){
  announce();
  return lionss_run_workload("FastqcTrim");
}
